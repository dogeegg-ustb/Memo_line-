from __future__ import annotations

from pathlib import Path
from typing import Any

import cv2
from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import QComboBox, QFileDialog, QHBoxLayout, QLabel, QListWidget, QMainWindow, QMessageBox, QPushButton, QSplitter, QStatusBar, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget

from .capture_service import CaptureError, CaptureService
from .exporter import Exporter
from .models import Profile, RecognitionOutcome
from .ocr_engine import RapidOcrEngine
from .profile_store import ProfileStore
from .recognition_pipeline import RecognitionPipeline
from .recognition_scheduler import RecognitionScheduler
from .roi_selector import RoiSelectorDialog
from .window_selector import WindowSelectorDialog
from .window_service import WindowInfo, inspect_window


def cv_to_pixmap(image: Any) -> QPixmap:
    if image is None:
        return QPixmap()
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w = rgb.shape[:2]
    return QPixmap.fromImage(QImage(rgb.data, w, h, w * 3, QImage.Format.Format_RGB888).copy())


class MainWindow(QMainWindow):
    def __init__(self, app_root: str | Path):
        super().__init__()
        self.app_root = Path(app_root)
        self.store = ProfileStore(self.app_root / "profiles")
        self.capture = CaptureService()
        self.profile: Profile | None = None
        self.profile_path: Path | None = None
        self.target_window: WindowInfo | None = None
        self.scheduler: RecognitionScheduler | None = None
        self.last_outcome: RecognitionOutcome | None = None
        self.setWindowTitle("CSP Panel Validator")
        self.resize(1320, 840)
        self._build_ui()
        self._refresh_profiles()
        QTimer.singleShot(0, self._bootstrap_flow)

    def _build_ui(self) -> None:
        self.profile_combo = QComboBox()
        self.profile_combo.currentIndexChanged.connect(self.load_selected_profile)
        self.window_label = QLabel("目标 CSP 窗口：未确认")
        self.window_label.setMinimumWidth(260)
        self.find_window_button = QPushButton("选择/重新查找 CSP")
        self.find_window_button.clicked.connect(self.choose_target_window)
        self.reselect_button = QPushButton("调整 ROI")
        self.reselect_button.clicked.connect(self.reselect)
        self.save_button = QPushButton("保存配置")
        self.save_button.clicked.connect(self.save_profile)
        self.once_button = QPushButton("识别一次")
        self.once_button.clicked.connect(lambda: self.start_recognition(True))
        self.start_button = QPushButton("开始持续识别")
        self.start_button.clicked.connect(lambda: self.start_recognition(False))
        self.stop_button = QPushButton("停止")
        self.stop_button.clicked.connect(self.stop_recognition)
        self.export_button = QPushButton("导出当前 JSON")
        self.export_button.clicked.connect(self.export_json)
        self.jsonl_button = QPushButton("追加会话 JSONL")
        self.jsonl_button.clicked.connect(self.export_jsonl)
        top = QHBoxLayout()
        top.addWidget(QLabel("用户配置")); top.addWidget(self.profile_combo, 1)
        top.addWidget(self.window_label, 2)
        for button in (self.find_window_button, self.reselect_button, self.save_button, self.once_button, self.start_button, self.stop_button, self.export_button, self.jsonl_button):
            top.addWidget(button)

        self.brush_label = QLabel("当前笔刷：unknown")
        self.status_label = QLabel("状态：未初始化")
        self.timing_label = QLabel("耗时：—")
        summary = QHBoxLayout()
        summary.addWidget(self.brush_label, 2); summary.addWidget(self.status_label, 1); summary.addWidget(self.timing_label, 1)

        self.parameter_table = QTableWidget(0, 7)
        self.parameter_table.setHorizontalHeaderLabels(["key", "标签", "类型", "值", "单位", "enabled", "status"])
        self.parameter_table.cellClicked.connect(self.highlight_parameter)
        self.evidence_list = QListWidget()
        self.preview_label = QLabel("暂无目标窗口客户区截图")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setMinimumSize(520, 380)
        self.overlay_label = QLabel("暂无识别证据叠加图")
        self.overlay_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.overlay_label.setMinimumSize(520, 380)
        tabs = QTabWidget()
        tabs.addTab(self.preview_label, "当前 ROI 截图")
        tabs.addTab(self.overlay_label, "识别证据叠加图")
        right_layout = QVBoxLayout()
        right_layout.addWidget(QLabel("当前帧参数（不包含旧帧残留）"))
        right_layout.addWidget(self.parameter_table, 2)
        right_layout.addWidget(QLabel("证据摘要"))
        right_layout.addWidget(self.evidence_list, 1)
        right_widget = QWidget(); right_widget.setLayout(right_layout)
        splitter = QSplitter()
        splitter.addWidget(tabs); splitter.addWidget(right_widget); splitter.setSizes([680, 580])
        central = QWidget()
        layout = QVBoxLayout(central)
        layout.addLayout(top); layout.addLayout(summary); layout.addWidget(splitter, 1)
        self.setCentralWidget(central)
        self.setStatusBar(QStatusBar())

    def _bootstrap_flow(self) -> None:
        if self.profile is None or self.profile_path is None:
            self.statusBar().showMessage("没有有效用户配置，正在打开初始化向导")
            self.choose_target_window(initializing=True)
            return
        self.statusBar().showMessage("请确认上次绑定的具体 CSP 窗口")
        self.choose_target_window(initializing=False)

    def _refresh_profiles(self, select_path: Path | None = None) -> None:
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        paths = self.store.list_user_profiles()
        for path in paths:
            self.profile_combo.addItem(path.stem, str(path))
        self.profile_combo.blockSignals(False)
        if not paths:
            self.profile = None
            self.profile_path = None
            return
        index = 0
        if select_path:
            for candidate in range(self.profile_combo.count()):
                if Path(self.profile_combo.itemData(candidate)) == select_path:
                    index = candidate
                    break
        self.profile_combo.setCurrentIndex(index)
        self.load_selected_profile(index)

    def load_selected_profile(self, index: int) -> None:
        if index < 0:
            return
        path = Path(self.profile_combo.itemData(index))
        try:
            profile = self.store.load(path)
            if profile.profile_kind != "user" or profile.target_window is None:
                raise ValueError("该文件不是完整的用户窗口配置")
        except Exception as exc:
            self.profile = None
            self.profile_path = None
            self.statusBar().showMessage(f"配置不可用：{exc}")
            return
        same_profile_runtime = self.profile_path == path and self.target_window is not None
        self.profile, self.profile_path = profile, path
        if not same_profile_runtime:
            self.target_window = None
            self.window_label.setText("目标 CSP 窗口：需重新确认")
            self.status_label.setText("状态：待确认目标窗口")

    def choose_target_window(self, initializing: bool = False) -> None:
        expected = self.profile.target_window if self.profile else None
        dialog = WindowSelectorDialog(expected, self)
        if dialog.exec() != dialog.DialogCode.Accepted:
            if initializing and self.profile is None:
                self.statusBar().showMessage("尚未完成初始化：请点击“选择/重新查找 CSP”并确认窗口")
            else:
                self.statusBar().showMessage("未确认目标 CSP 窗口；不会退回整屏识别")
            return
        selected = dialog.selected_window()
        if selected is None:
            return
        self.target_window = selected
        self.window_label.setText(f"目标 CSP：{selected.title or selected.exe_name} | HWND {selected.hwnd}")
        if initializing or self.profile is None:
            self._open_roi_selector()
            return
        issues = self.store.window_compatibility(self.profile, selected.as_dict())
        if issues:
            self.status_label.setText("状态：needs_reselection")
            self.statusBar().showMessage("窗口已重新匹配，但需要重新框选：" + "；".join(issues))
            QMessageBox.information(self, "窗口尺寸或 DPI 已变化", "当前窗口不能安全复用旧 ROI，请点击“调整 ROI”重新框选。\n\n" + "\n".join(issues))
        else:
            self.status_label.setText("状态：窗口已确认")
            self.statusBar().showMessage("已确认具体 CSP 窗口；ROI 坐标相对于该窗口客户区捕获图像")

    def _open_roi_selector(self) -> None:
        if self.target_window is None:
            return
        try:
            frame = self.capture.capture_window_snapshot(self.target_window)
        except Exception as exc:
            QMessageBox.critical(self, "CSP 窗口捕获失败", f"无法冻结目标窗口客户区截图：\n{exc}\n\n不会退回整屏截图，请确认 CSP 窗口可见后点击“重新查找 CSP”。")
            self.status_label.setText("状态：unavailable")
            return
        dialog = RoiSelectorDialog(frame.image, self.target_window, self.profile.name if self.profile else "CSP 面板配置", self, self.profile.rois if self.profile else None)
        if dialog.exec() != dialog.DialogCode.Accepted:
            self.statusBar().showMessage("初始化未保存；可以重新选择 CSP 窗口")
            return
        try:
            new_profile = dialog.profile()
            self.store.validate(new_profile)
            self.profile = new_profile
            self.profile_path = self.store.save(new_profile)
        except Exception as exc:
            QMessageBox.critical(self, "保存配置失败", str(exc))
            return
        self._refresh_profiles(self.profile_path)
        self.statusBar().showMessage("配置已保存，正在对全部 ROI 执行首次完整识别供核对")
        self.start_recognition(True)

    def reselect(self) -> None:
        if self.target_window is None:
            self.choose_target_window(initializing=self.profile is None)
            return
        fresh = inspect_window(self.target_window.hwnd)
        if fresh is None or fresh.minimized or not fresh.visible:
            self.status_label.setText("状态：unavailable")
            self.clear_current_result("目标 CSP 窗口已关闭、最小化或不可见，请重新查找")
            self.choose_target_window(initializing=False)
            return
        self.target_window = fresh
        self._open_roi_selector()

    def save_profile(self) -> None:
        if self.profile is None or self.profile.target_window is None:
            QMessageBox.information(self, "需要初始化", "请先选择具体 CSP 窗口并完成 ROI 框选。")
            self.choose_target_window(initializing=self.profile is None)
            return
        try:
            self.profile_path = self.store.save(self.profile, self.profile_path)
            self._refresh_profiles(self.profile_path)
            self.statusBar().showMessage(f"已保存用户窗口配置：{self.profile_path.name}")
        except Exception as exc:
            QMessageBox.critical(self, "保存失败", str(exc))

    def start_recognition(self, once: bool) -> None:
        if self.profile is None or self.profile.target_window is None:
            QMessageBox.information(self, "需要初始化", "请先选择 CSP 窗口并框选 ROI。")
            self.choose_target_window(initializing=True)
            return
        if self.target_window is None:
            QMessageBox.information(self, "需要确认窗口", "后续启动必须重新发现并确认具体 CSP 窗口。")
            self.choose_target_window(initializing=False)
            return
        self.stop_recognition()
        engine = RapidOcrEngine()
        if not engine.available:
            self.status_label.setText("状态：unavailable")
            self.statusBar().showMessage("RapidOCR 不可用：" + engine.error)
        self.scheduler = RecognitionScheduler(self.profile, self.capture, RecognitionPipeline(engine), self.target_window)
        self.scheduler.result_ready.connect(self.receive_outcome)
        self.scheduler.message.connect(self.statusBar().showMessage)
        self.scheduler.running_changed.connect(lambda running: self.statusBar().showMessage("识别任务运行中" if running else "识别任务空闲"))
        if once:
            self.scheduler.request(True)
        else:
            self.scheduler.start()
            self.start_button.setEnabled(False)

    def stop_recognition(self) -> None:
        if self.scheduler:
            self.scheduler.stop()
        self.start_button.setEnabled(True)

    def clear_current_result(self, message: str) -> None:
        self.last_outcome = None
        self.brush_label.setText("当前笔刷：unknown")
        self.status_label.setText("状态：unavailable")
        self.timing_label.setText("耗时：—")
        self.parameter_table.setRowCount(0)
        self.evidence_list.clear()
        self.preview_label.setPixmap(QPixmap()); self.preview_label.setText("当前没有可用目标窗口截图")
        self.overlay_label.setPixmap(QPixmap()); self.overlay_label.setText("当前没有识别证据")
        self.statusBar().showMessage(message)

    def receive_outcome(self, outcome: RecognitionOutcome) -> None:
        self.last_outcome = outcome
        result = outcome.result
        brush = result.get("brush", {})
        self.brush_label.setText(f"当前笔刷：{brush.get('name', 'unknown')}（{brush.get('source', 'unknown')}）")
        self.status_label.setText(f"状态：{result.get('status', 'unknown')} | 后端：{result.get('capture_backend', 'unknown')}")
        timings = result.get("timings_ms", {})
        self.timing_label.setText(f"耗时：总 {timings.get('total', 0)} ms / OCR {timings.get('ocr', 0)} ms")
        self.parameter_table.setRowCount(0)
        for parameter in result.get("parameters", []):
            row = self.parameter_table.rowCount(); self.parameter_table.insertRow(row)
            values = [parameter.get("key"), parameter.get("label"), parameter.get("type"), parameter.get("value"), parameter.get("unit") or "", parameter.get("enabled"), parameter.get("status")]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value)); item.setData(Qt.ItemDataRole.UserRole, parameter); self.parameter_table.setItem(row, column, item)
        self.evidence_list.clear()
        evidence_items = result.get("brush", {}).get("evidence", []) + [entry for parameter in result.get("parameters", []) for entry in parameter.get("evidence", [])]
        for evidence in evidence_items:
            self.evidence_list.addItem(f"{evidence.get('type')} | ROI {evidence.get('roi_id')} | bbox={evidence.get('bbox')} | {evidence.get('reason')}")
        if outcome.roi_images:
            first = next(iter(outcome.roi_images))
            self.preview_label.setText(""); self.preview_label.setPixmap(cv_to_pixmap(outcome.roi_images[first]).scaled(self.preview_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            self.overlay_label.setText(""); self.overlay_label.setPixmap(cv_to_pixmap(outcome.overlays.get(first)).scaled(self.overlay_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        elif result.get("status") in ("unavailable", "needs_reselection"):
            self.preview_label.setPixmap(QPixmap()); self.preview_label.setText("当前没有可用目标窗口截图")
            self.overlay_label.setPixmap(QPixmap()); self.overlay_label.setText("当前没有识别证据")

    def highlight_parameter(self, row: int, column: int) -> None:
        if not self.last_outcome or row < 0 or row >= len(self.last_outcome.result.get("parameters", [])):
            return
        parameter = self.last_outcome.result["parameters"][row]
        evidence = parameter.get("evidence", [])
        if evidence:
            self.statusBar().showMessage(f"已选中证据：ROI {evidence[0].get('roi_id')} bbox={evidence[0].get('bbox')}")

    def export_json(self) -> None:
        if not self.last_outcome:
            QMessageBox.information(self, "没有结果", "请先识别一次")
            return
        path, _ = QFileDialog.getSaveFileName(self, "导出当前 JSON", str(self.app_root / "exports" / "current.json"), "JSON (*.json)")
        if path:
            Exporter.write_json(self.last_outcome.result, path); self.statusBar().showMessage(f"已导出 {path}")

    def export_jsonl(self) -> None:
        if not self.last_outcome:
            QMessageBox.information(self, "没有结果", "请先识别一次")
            return
        path, _ = QFileDialog.getSaveFileName(self, "追加会话 JSONL", str(self.app_root / "exports" / "session.jsonl"), "JSON Lines (*.jsonl)")
        if path:
            Exporter.append_jsonl(self.last_outcome.result, path); self.statusBar().showMessage(f"已追加 {path}")

    def closeEvent(self, event: Any) -> None:
        self.stop_recognition(); self.capture.close(); event.accept()
