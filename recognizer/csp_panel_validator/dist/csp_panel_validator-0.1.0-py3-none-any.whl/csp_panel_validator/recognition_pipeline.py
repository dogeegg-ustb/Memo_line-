from __future__ import annotations

import time
from typing import Any

import cv2

from .capture_service import CaptureService
from .models import CaptureFrame, Profile, RecognitionOutcome
from .panel_parser import PanelParser
from .state_assembler import StateAssembler
from .visual_state import VisualStateRecognizer


class RecognitionPipeline:
    def __init__(self, ocr_engine: Any, visual: VisualStateRecognizer | None = None, parser: PanelParser | None = None, assembler: StateAssembler | None = None):
        self.ocr = ocr_engine
        self.visual = visual or VisualStateRecognizer()
        self.parser = parser or PanelParser()
        self.assembler = assembler or StateAssembler()

    def process(self, frame: CaptureFrame, profile: Profile, crops: dict[str, Any] | None = None, sidecar: Any = None) -> RecognitionOutcome:
        started = time.perf_counter()
        crops = crops or CaptureService.crop_all(frame, profile)
        capture_ms = round((time.perf_counter() - started) * 1000)
        ocr_started = time.perf_counter()
        recognitions = []
        overlay_images: dict[str, Any] = {}
        try:
            for roi in profile.rois:
                image = crops[roi.id]
                if sidecar is not None:
                    items = sidecar.recognize(image, roi.id)
                else:
                    items = self.ocr.recognize(image)
                states = self.visual.analyze(image, items)
                recognition = self.parser.parse(roi.id, roi.role, items, states)
                recognitions.append(recognition)
                overlay_images[roi.id] = self._overlay(image, recognition)
        except Exception as exc:
            # A model/capture failure is returned as an explicit unavailable snapshot.
            recognized_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            result = {
                "schema_version": 1, "frame_id": frame.frame_id, "captured_at": frame.captured_at, "recognized_at": recognized_at, "last_observed_at": recognized_at,
                "status": "unavailable", "brush": {"name": "unknown", "status": "unknown", "candidates": [], "evidence": []}, "parameters": [],
                "unresolved": [{"reason": str(exc), "status": "unavailable"}], "capture_backend": frame.capture_backend, "capture_scope": "client", "timings_ms": {"capture": capture_ms, "ocr": round((time.perf_counter() - ocr_started) * 1000), "parse": 0, "total": round((time.perf_counter() - started) * 1000)},
            }
            return RecognitionOutcome(result, crops, overlay_images)
        ocr_ms = round((time.perf_counter() - ocr_started) * 1000)
        parse_started = time.perf_counter()
        recognized_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        result = self.assembler.assemble(frame.frame_id, frame.captured_at, recognized_at, recognitions, {"capture": capture_ms, "ocr": ocr_ms, "parse": 0, "total": 0})
        result["timings_ms"]["parse"] = round((time.perf_counter() - parse_started) * 1000)
        result["timings_ms"]["total"] = round((time.perf_counter() - started) * 1000)
        result["capture_backend"] = frame.capture_backend
        result["capture_scope"] = "client"
        return RecognitionOutcome(result, crops, overlay_images)

    @staticmethod
    def _overlay(image: Any, recognition: Any) -> Any:
        overlay = image.copy()
        for item in recognition.ocr:
            x, y, w, h = item.bbox()
            color = (0, 220, 0)
            cv2.rectangle(overlay, (x, y), (x + w, y + h), color, 1)
            cv2.putText(overlay, item.text[:24], (x, max(12, y - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.42, color, 1, cv2.LINE_AA)
        for parameter in recognition.parameters:
            for evidence in parameter.get("evidence", []):
                x, y, w, h = evidence.get("bbox", [0, 0, 0, 0])
                cv2.rectangle(overlay, (int(x), int(y)), (int(x + w), int(y + h)), (0, 165, 255), 2)
        return overlay


def image_signature(image: Any) -> tuple[int, float]:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
    small = cv2.resize(gray, (64, 64), interpolation=cv2.INTER_AREA)
    return int(cv2.norm(small, cv2.NORM_L1)), float(small.mean())


def changed(previous: tuple[int, float] | None, current: tuple[int, float], threshold: float) -> bool:
    if previous is None:
        return True
    return abs(current[0] - previous[0]) / max(1, 64 * 64 * 255) * 100.0 >= threshold or abs(current[1] - previous[1]) >= threshold
