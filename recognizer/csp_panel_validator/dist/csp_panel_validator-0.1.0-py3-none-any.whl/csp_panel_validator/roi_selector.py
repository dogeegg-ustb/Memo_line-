from __future__ import annotations

import uuid
from typing import Any

import cv2
import numpy as np

from .models import MonitorProfile, Profile, Rect, RoiDefinition
from .window_service import WindowInfo

try:
    from PySide6.QtCore import QPoint, QRect, Qt, Signal
    from PySide6.QtGui import QImage, QPainter, QPen, QPixmap
    from PySide6.QtWidgets import QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPushButton, QSpinBox, QVBoxLayout, QWidget
except ImportError:  # pragma: no cover
    QDialog = object  # type: ignore


def bgr_to_pixmap(image: np.ndarray) -> Any:
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    height, width = rgb.shape[:2]
    qimage = QImage(rgb.data, width, height, width * 3, QImage.Format.Format_RGB888).copy()
    return QPixmap.fromImage(qimage)


if QDialog is not object:
    class _Canvas(QWidget):
        changed = Signal()

        def __init__(self, image: np.ndarray):
            super().__init__()
            self.image = image
            self.pixmap = bgr_to_pixmap(image)
            self.rois: list[RoiDefinition] = []
            self.active = -1
            self.drag_start = None
            self.drag_mode = "new"
            self.drag_original = None
            self._preview_rect = None
            self.setMinimumSize(700, 450)
            self.setMouseTracking(True)

        def _scale(self) -> tuple[float, float, float]:
            scale = min(self.width() / self.pixmap.width(), self.height() / self.pixmap.height())
            ox = (self.width() - self.pixmap.width() * scale) / 2
            oy = (self.height() - self.pixmap.height() * scale) / 2
            return scale, ox, oy

        def _to_image(self, point: QPoint) -> tuple[int, int]:
            scale, ox, oy = self._scale()
            x = round((point.x() - ox) / scale)
            y = round((point.y() - oy) / scale)
            return max(0, min(self.image.shape[1], x)), max(0, min(self.image.shape[0], y))

        def _inside_image(self, point: QPoint) -> bool:
            scale, ox, oy = self._scale()
            return ox <= point.x() <= ox + self.pixmap.width() * scale and oy <= point.y() <= oy + self.pixmap.height() * scale

        def _to_widget(self, point: tuple[int, int]) -> QPoint:
            scale, ox, oy = self._scale()
            return QPoint(round(point[0] * scale + ox), round(point[1] * scale + oy))

        def paintEvent(self, event: Any) -> None:
            painter = QPainter(self)
            scale, ox, oy = self._scale()
            painter.drawPixmap(QRect(round(ox), round(oy), round(self.pixmap.width() * scale), round(self.pixmap.height() * scale)), self.pixmap)
            for index, roi in enumerate(self.rois):
                top_left = self._to_widget((roi.rect.x, roi.rect.y))
                bottom_right = self._to_widget((roi.rect.x + roi.rect.width, roi.rect.y + roi.rect.height))
                color = Qt.GlobalColor.green if roi.role == "tool_properties" else Qt.GlobalColor.cyan
                if index == self.active:
                    color = Qt.GlobalColor.yellow
                pen = QPen(color, 3 if index == self.active else 2)
                painter.setPen(pen)
                painter.drawRect(QRect(top_left, bottom_right))
                painter.drawText(top_left + QPoint(4, 18), f"{index + 1}: {roi.name} [{roi.role}]")
            if self._preview_rect:
                top_left = self._to_widget((self._preview_rect.x, self._preview_rect.y))
                bottom_right = self._to_widget((self._preview_rect.x + self._preview_rect.width, self._preview_rect.y + self._preview_rect.height))
                painter.setPen(QPen(Qt.GlobalColor.yellow, 2, Qt.PenStyle.DashLine))
                painter.drawRect(QRect(top_left, bottom_right))

        def mousePressEvent(self, event: Any) -> None:
            if event.button() != Qt.MouseButton.LeftButton:
                return
            if not self._inside_image(event.position().toPoint()):
                return
            point = self._to_image(event.position().toPoint())
            self.drag_start = point
            self.drag_mode = "new"
            self.drag_original = None
            for index, roi in enumerate(self.rois):
                r = roi.rect
                if r.x <= point[0] <= r.x + r.width and r.y <= point[1] <= r.y + r.height:
                    self.active = index
                    self.drag_original = r
                    self.drag_mode = "resize" if point[0] >= r.x + r.width - 20 and point[1] >= r.y + r.height - 20 else "move"
                    break
            self.update()

        def mouseMoveEvent(self, event: Any) -> None:
            if self.drag_start is None:
                return
            point = self._to_image(event.position().toPoint())
            x0, y0 = self.drag_start
            if self.drag_mode == "new":
                rect = Rect(min(x0, point[0]), min(y0, point[1]), abs(point[0] - x0), abs(point[1] - y0))
                if rect.width > 5 and rect.height > 5:
                    self._preview_rect = rect
            elif self.active >= 0 and self.drag_original:
                original = self.drag_original
                if self.drag_mode == "move":
                    nx = max(0, min(self.image.shape[1] - original.width, original.x + point[0] - x0))
                    ny = max(0, min(self.image.shape[0] - original.height, original.y + point[1] - y0))
                    self.rois[self.active].rect = Rect(nx, ny, original.width, original.height)
                else:
                    width = max(5, min(self.image.shape[1] - original.x, point[0] - original.x))
                    height = max(5, min(self.image.shape[0] - original.y, point[1] - original.y))
                    self.rois[self.active].rect = Rect(original.x, original.y, width, height)
                self.changed.emit()
            self.update()

        def mouseReleaseEvent(self, event: Any) -> None:
            if self.drag_start is None:
                return
            if self.drag_mode == "new" and self._preview_rect is not None:
                rect = self._preview_rect
                if rect.width > 0 and rect.height > 0:
                    self.rois.append(RoiDefinition(str(uuid.uuid4())[:8], f"ROI {len(self.rois) + 1}", "tool_properties", rect))
                self.active = len(self.rois) - 1
                del self._preview_rect
                self.changed.emit()
            self.drag_start = None
            self.drag_original = None
            self.update()


    class RoiSelectorDialog(QDialog):
        def __init__(self, image: np.ndarray, window: WindowInfo, profile_name: str = "CSP 面板配置", parent: Any = None, existing_rois: list[RoiDefinition] | None = None):
            super().__init__(parent)
            self.setWindowTitle("框选 CSP 面板 ROI（物理像素）")
            self.resize(1100, 760)
            self.image = image
            self.window = window
            self.canvas = _Canvas(image)
            self.canvas.rois = [RoiDefinition(roi.id, roi.name, roi.role, Rect(roi.rect.x, roi.rect.y, roi.rect.width, roi.rect.height)) for roi in (existing_rois or [])]
            self.canvas.active = 0 if self.canvas.rois else -1
            self.list = QListWidget()
            self.name_edit = QLineEdit(profile_name)
            self.role_combo = QComboBox()
            self.role_combo.addItem("工具属性（必选）", "tool_properties")
            self.role_combo.addItem("子工具列表（可选）", "tool_list")
            self.delete_button = QPushButton("删除选中 ROI")
            self.delete_button.clicked.connect(self.delete_selected)
            self.list.currentRowChanged.connect(self.select_row)
            self.role_combo.currentIndexChanged.connect(self.apply_fields)
            self.list.itemChanged.connect(self.apply_fields)
            left = QVBoxLayout()
            left.addWidget(QLabel("冻结截图：拖拽新增；拖动框体移动；右下角拖动调整大小"))
            left.addWidget(self.canvas, 1)
            right = QVBoxLayout()
            form = QFormLayout()
            form.addRow("配置名称", self.name_edit)
            form.addRow("当前 ROI 角色", self.role_combo)
            right.addLayout(form)
            right.addWidget(self.list, 1)
            right.addWidget(self.delete_button)
            buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
            right.addWidget(buttons)
            layout = QHBoxLayout(self)
            layout.addLayout(left, 3)
            layout.addLayout(right, 1)
            self.canvas.changed.connect(self.refresh_list)
            self.refresh_list()

        def refresh_list(self) -> None:
            current = self.canvas.active
            self.list.blockSignals(True)
            self.list.clear()
            for roi in self.canvas.rois:
                item = QListWidgetItem(f"{roi.name} | {roi.rect.to_list()} | {roi.role}")
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
                self.list.addItem(item)
            self.list.blockSignals(False)
            if self.canvas.rois:
                self.list.setCurrentRow(max(0, min(current, len(self.canvas.rois) - 1)))

        def select_row(self, row: int) -> None:
            self.canvas.active = row
            if 0 <= row < len(self.canvas.rois):
                self.role_combo.setCurrentIndex(0 if self.canvas.rois[row].role == "tool_properties" else 1)
            self.canvas.update()

        def apply_fields(self) -> None:
            row = self.list.currentRow()
            if 0 <= row < len(self.canvas.rois):
                self.canvas.rois[row].role = self.role_combo.currentData()
                item = self.list.item(row)
                if item:
                    item.setText(f"{self.canvas.rois[row].name} | {self.canvas.rois[row].rect.to_list()} | {self.canvas.rois[row].role}")
                self.canvas.update()

        def delete_selected(self) -> None:
            row = self.list.currentRow()
            if 0 <= row < len(self.canvas.rois):
                self.canvas.rois.pop(row)
                self.canvas.active = min(row, len(self.canvas.rois) - 1)
                self.refresh_list()
                self.canvas.update()

        def profile(self) -> Profile:
            if not any(roi.role == "tool_properties" for roi in self.canvas.rois):
                raise ValueError("至少需要一个工具属性 ROI")
            monitor = MonitorProfile(
                screen_id=f"window:{self.window.exe_name}:{self.window.class_name}",
                name=self.window.title or self.window.exe_name,
                geometry=self.window.client_rect,
                capture_size=self.window.capture_size,
                dpi=self.window.dpi,
                device_pixel_ratio=self.window.dpi / 96.0,
                output_index=self.window.output_index,
            )
            return Profile(
                self.name_edit.text().strip() or "CSP 面板配置",
                monitor,
                self.canvas.rois,
                profile_kind="user",
                target_window=self.window.binding(),
            )

        def accept(self) -> None:
            try:
                self.profile()
            except ValueError as exc:
                QMessageBox.warning(self, "配置不完整", str(exc))
                return
            super().accept()
else:
    class RoiSelectorDialog:  # type: ignore
        pass
