from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .models import OcrText


class OcrUnavailable(RuntimeError):
    pass


class RapidOcrEngine:
    """Adapter for rapidocr_onnxruntime; the model is kept resident for the process lifetime."""

    def __init__(self):
        self.available = False
        self.error = ""
        self._engine: Any = None
        self._factory: Any = None
        self.package_name = ""
        try:
            from rapidocr import RapidOCR  # type: ignore

            # Import is cheap; instantiate lazily on the worker so model setup never blocks Qt.
            self._factory = RapidOCR
            self.package_name = "rapidocr"
            self.available = True
        except Exception as modern_exc:  # pragma: no cover - depends on installed environment
            try:
                from rapidocr_onnxruntime import RapidOCR  # type: ignore

                self._factory = RapidOCR
                self.package_name = "rapidocr_onnxruntime"
                self.available = True
            except Exception as legacy_exc:  # includes missing runtime/model download errors
                self.error = f"rapidocr: {modern_exc}; legacy adapter: {legacy_exc}"

    def warmup(self) -> None:
        if self.available:
            blank = np.zeros((32, 128, 3), dtype=np.uint8)
            self.recognize(blank)

    def recognize(self, image: np.ndarray) -> list[OcrText]:
        if not self.available or self._factory is None:
            raise OcrUnavailable(self.error or "RapidOCR 不可用")
        if self._engine is None:
            self._engine = self._factory()
        raw = self._engine(image)
        return normalize_rapid_result(raw[0] if isinstance(raw, tuple) else raw)


def normalize_rapid_result(result: Any) -> list[OcrText]:
    if result is None:
        return []
    if hasattr(result, "boxes") and hasattr(result, "txts"):
        boxes = result.boxes if result.boxes is not None else []
        texts = result.txts if result.txts is not None else ()
        scores = getattr(result, "scores", None)
        scores = scores if scores is not None else ()
        entries = []
        for index, (box, text) in enumerate(zip(boxes, texts)):
            entries.append([box, text, scores[index] if index < len(scores) else None])
        return normalize_rapid_result(entries)
    if isinstance(result, np.ndarray) and result.size == 0:
        return []
    normalized: list[OcrText] = []
    for item in result:
        if isinstance(item, dict):
            box = item.get("box") or item.get("points") or item.get("poly")
            text = item.get("text") or item.get("txt") or ""
            score = item.get("score", item.get("confidence"))
        elif isinstance(item, (list, tuple)) and len(item) >= 3:
            box, text, score = item[0], item[1], item[2]
        else:
            continue
        if not box or text is None:
            continue
        try:
            normalized.append(OcrText(str(text), float(score) if score is not None else None, [[float(p[0]), float(p[1])] for p in box]))
        except (TypeError, ValueError, IndexError):
            continue
    return normalized


class SidecarOcrEngine:
    """Deterministic offline OCR input for parser/replay validation."""

    def __init__(self, path: str | Path):
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        self.data = data
        self.available = True

    def recognize(self, image: np.ndarray, roi_id: str | None = None) -> list[OcrText]:
        entries = self.data.get(roi_id or "", [])
        return normalize_rapid_result(entries)


class PaddleReferenceEngine:
    """Optional reference adapter; never selected by the live UI."""

    def __init__(self):
        self.available = False
        self.error = "PaddleOCR 未安装"
        try:
            from paddleocr import PaddleOCR  # type: ignore

            self._engine = PaddleOCR(use_angle_cls=True, lang="ch", show_log=False)
            self.available = True
        except Exception as exc:
            self.error = str(exc)

    def recognize(self, image: np.ndarray) -> list[OcrText]:
        if not self.available:
            raise OcrUnavailable(self.error)
        raw = self._engine.ocr(image, cls=True)
        entries = []
        for page in raw or []:
            for line in page or []:
                if len(line) >= 2:
                    entries.append([line[0], line[1][0], line[1][1]])
        return normalize_rapid_result(entries)
