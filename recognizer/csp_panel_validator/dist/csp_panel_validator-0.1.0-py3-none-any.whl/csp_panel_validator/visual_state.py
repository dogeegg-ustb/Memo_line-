from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from .models import OcrText, VisualState


class VisualStateRecognizer:
    """Visual evidence is computed from the same ROI image passed to OCR."""

    def analyze(self, image: np.ndarray, items: list[OcrText]) -> list[VisualState]:
        if image is None or image.size == 0:
            return [VisualState() for _ in items]
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        states: list[VisualState] = []
        heights = [item.bbox()[3] for item in items if item.bbox()[3] > 0]
        median_h = float(np.median(heights)) if heights else 14.0
        for item in items:
            x, y, w, h = item.bbox()
            y0, y1 = max(0, int(y - 0.45 * h)), min(gray.shape[0], int(y + 1.45 * h))
            x0, x1 = max(0, int(x - 0.8 * h)), min(gray.shape[1], int(x + w + 0.8 * h))
            row = gray[y0:y1, x0:x1]
            evidence: list[dict[str, Any]] = []
            selected, selected_score = self._selected_signal(gray, x, y, w, h, median_h)
            if selected_score is not None:
                evidence.append({"roi_id": "", "bbox": [x, y, w, h], "type": "selected_background", "ocr_score": item.score, "reason": "当前帧行背景与邻近行的亮度/边框差异"})
            checkbox, enabled, checkbox_box = self._checkbox_signal(row, x0, y0, h)
            if checkbox_box:
                evidence.append({"roi_id": "", "bbox": checkbox_box, "type": "checkbox", "ocr_score": item.score, "reason": "当前帧文字左侧方框的边框与填充分析"})
            if row.size:
                # A disabled control is often low contrast, but this remains an explicit heuristic.
                contrast = float(np.std(row))
                if contrast < 8.0:
                    enabled = "disabled"
                    evidence.append({"roi_id": "", "bbox": [x, y, w, h], "type": "disabled_style", "ocr_score": item.score, "reason": "控件区域对比度过低，标记为可能禁用"})
            states.append(VisualState(selected=selected, selected_score=selected_score, checkbox=checkbox, enabled=enabled, evidence=evidence))
        return states

    @staticmethod
    def _selected_signal(gray: np.ndarray, x: int, y: int, w: int, h: int, median_h: float) -> tuple[str, float | None]:
        if h <= 0:
            return "unknown", None
        pad = max(2, int(median_h * 0.35))
        y0, y1 = max(0, y - pad), min(gray.shape[0], y + h + pad)
        x0, x1 = max(0, x - int(8 * median_h)), min(gray.shape[1], x + w + int(8 * median_h))
        band = gray[y0:y1, x0:x1]
        if band.size == 0:
            return "unknown", None
        row_mean = float(np.mean(band))
        above = float(np.mean(gray[max(0, y0 - h * 2):y0])) if y0 > 0 else row_mean
        below = float(np.mean(gray[y1:min(gray.shape[0], y1 + h * 2)])) if y1 < gray.shape[0] else row_mean
        contrast = abs(row_mean - (above + below) / 2.0) / 255.0
        edge = float(np.mean(cv2.Canny(band, 60, 120))) / 255.0
        score = min(1.0, contrast * 2.2 + edge * 0.35)
        if score >= 0.25:
            return "selected", score
        if score <= 0.10:
            return "not_selected", score
        return "unknown", score

    @staticmethod
    def _checkbox_signal(row: np.ndarray, origin_x: int, origin_y: int, h: int) -> tuple[str, str, list[int] | None]:
        if row.size == 0 or h < 4:
            return "unknown", "unknown", None
        size = max(6, int(h * 0.9))
        search = row[:, : min(row.shape[1], size * 2)]
        if search.size == 0:
            return "unknown", "unknown", None
        _, threshold = cv2.threshold(search, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        contours, _ = cv2.findContours(threshold, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            x, y, w, h2 = cv2.boundingRect(contour)
            if 0.55 * size <= w <= 1.7 * size and 0.55 * size <= h2 <= 1.7 * size and 0.55 <= w / max(h2, 1) <= 1.8:
                patch = search[max(0, y):y + h2, max(0, x):x + w]
                fill = float(np.mean(patch < 100)) if patch.size else 0.0
                checkbox = "checked" if fill > 0.35 else "unchecked"
                return checkbox, "enabled", [origin_x + x, origin_y + y, w, h2]
        return "not_checkbox", "unknown", None
