from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from .models import OcrText, RoiRecognition, RoiRole, VisualState


NUMBER_RE = re.compile(r"(?<![\w.])[-+]?\d+(?:[.,]\d+)?")
UNIT_RE = re.compile(r"(%|％|px|像素|度|°|ms|毫米|mm)", re.IGNORECASE)


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text.replace("\u3000", " ")).strip()


def _rows(items: list[OcrText], states: list[VisualState]) -> list[list[tuple[OcrText, VisualState]]]:
    pairs = sorted(zip(items, states), key=lambda pair: (pair[0].bbox()[1], pair[0].bbox()[0]))
    rows: list[list[tuple[OcrText, VisualState]]] = []
    for item, state in pairs:
        _, y, _, h = item.bbox()
        center = y + h / 2
        placed = False
        for row in rows:
            centers = [p[0].bbox()[1] + p[0].bbox()[3] / 2 for p in row]
            if abs(center - sum(centers) / len(centers)) <= max(10.0, h * 0.75):
                row.append((item, state))
                placed = True
                break
        if not placed:
            rows.append([(item, state)])
    for row in rows:
        row.sort(key=lambda pair: pair[0].bbox()[0])
    return rows


class PanelParser:
    """Rebuilds relationships from only the current frame's OCR and visual evidence."""

    LABELS = {
        "brush_size": ("笔刷尺寸", "画笔大小", "brush size", "size", "大小"),
        "opacity": ("不透明度", "透明度", "opacity"),
        "stabilization": ("手颤修正", "稳定", "稳定性", "stabilization", "correction"),
        "antialiasing": ("消除锯齿", "抗锯齿", "antialiasing", "anti-alias"),
    }
    NON_NAME = ("工具属性", "工具属性", "子工具", "sub tool", "tool property", "参数")

    def parse(self, roi_id: str, role: RoiRole, items: list[OcrText], visual: list[VisualState]) -> RoiRecognition:
        for state in visual:
            for evidence in state.evidence:
                evidence["roi_id"] = roi_id
        recognition = RoiRecognition(roi_id, role, items, visual)
        if not items:
            recognition.unresolved.append({"roi_id": roi_id, "reason": "当前帧没有可用 OCR 文字", "status": "unknown"})
            return recognition
        rows = _rows(items, visual)
        if role == "tool_list":
            recognition.brush_candidates = self._parse_tool_list(roi_id, rows)
        else:
            recognition.parameters, recognition.brush_candidates, recognition.unresolved = self._parse_properties(roi_id, rows)
        return recognition

    def _parse_tool_list(self, roi_id: str, rows: list[list[tuple[OcrText, VisualState]]]) -> list[dict[str, Any]]:
        candidates: list[dict[str, Any]] = []
        for row in rows:
            text = _clean(" ".join(item.text for item, _ in row))
            if not text or self._is_heading(text):
                continue
            selected_states = [state for _, state in row if state.selected == "selected"]
            selected = bool(selected_states)
            score = max((state.selected_score or 0.0 for state in selected_states), default=0.0)
            first = row[0][0]
            candidates.append({
                "name": text,
                "status": "selected" if selected else "candidate",
                "incomplete": self._looks_truncated(text, first.bbox()),
                "evidence": self._evidence(roi_id, row, "selected_background" if selected else "ocr_text", "子工具列表当前行的选中背景与文字证据"),
                "selection_score": score,
            })
        return candidates

    def _parse_properties(self, roi_id: str, rows: list[list[tuple[OcrText, VisualState]]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        parameters: list[dict[str, Any]] = []
        brush_candidates: list[dict[str, Any]] = []
        unresolved: list[dict[str, Any]] = []
        for row in rows:
            text = _clean(" ".join(item.text for item, _ in row))
            if not text:
                continue
            numeric_tokens = [item for item, _ in row if NUMBER_RE.search(item.text)]
            check_states = [state for _, state in row if state.checkbox != "not_checkbox"]
            label_item = row[0][0]
            key = self._key_for_label(text)
            if check_states:
                state = next((s for s in check_states if s.checkbox in ("checked", "unchecked")), check_states[0])
                parameters.append(self._parameter(roi_id, key or "", text, "checkbox", state.checkbox if state.checkbox != "not_checkbox" else "unknown", None, "unknown", self._evidence(roi_id, row, "checkbox", "文字左侧复选框与当前帧填充状态"), state.enabled))
                continue
            if numeric_tokens:
                value_token = numeric_tokens[-1]
                match = NUMBER_RE.search(value_token.text)
                if match:
                    raw = match.group(0)
                    value = self._number(raw)
                    unit_match = UNIT_RE.search(value_token.text[match.end():]) or UNIT_RE.search(text)
                    unit = unit_match.group(1) if unit_match else None
                    label = _clean(text[:text.rfind(raw)]).strip(" :：-") or text
                    parameters.append(self._parameter(roi_id, key or self._stable_key(label), label, "number", value, raw, unit, self._evidence(roi_id, row, "ocr_text", "当前帧同一行的标签与数值邻接关系"), self._enabled(row)))
                    continue
            options = [item for item, _ in row if item is not label_item]
            if key == "antialiasing" and options:
                selected = next((item.text for item, state in row if item is not label_item and state.selected == "selected"), None)
                status = "ok" if selected else "partial"
                parameters.append(self._parameter(roi_id, key, _clean(label_item.text), "enum", _clean(selected) if selected else "unknown", None, None, self._evidence(roi_id, row, "selected_background", "当前帧按钮组中选中项与标签的行内关系"), self._enabled(row), status=status))
                continue
            if key:
                kind = "enum" if key == "antialiasing" else "number"
                parameters.append(self._parameter(roi_id, key, _clean(text), kind, "unknown", None, None, self._evidence(roi_id, row, "ocr_text", "当前帧发现参数标签，但没有可可靠绑定的当前值"), self._enabled(row), status="partial"))
                continue
            if self._is_name_candidate(text):
                brush_candidates.append({"name": text, "status": "candidate", "incomplete": self._looks_truncated(text, label_item.bbox()), "evidence": self._evidence(roi_id, row, "ocr_text", "工具属性 ROI 中非标题、非参数标签的当前帧文本")})
            elif len(text) >= 2 and not self._is_heading(text):
                unresolved.append({"roi_id": roi_id, "raw_text": text, "evidence": self._evidence(roi_id, row, "ocr_text", "当前帧文字未能可靠绑定到数值、枚举或复选框")})
        return parameters, brush_candidates, unresolved

    @staticmethod
    def _parameter(roi_id: str, key: str, label: str, kind: str, value: Any, raw: str | None, unit: str | None, evidence: list[dict[str, Any]], enabled: str, status: str = "ok") -> dict[str, Any]:
        return {"key": key or "unresolved", "label": label, "type": kind, "value": value, "unit": unit, "raw_text": raw, "enabled": enabled, "status": status, "evidence": evidence}

    @staticmethod
    def _evidence(roi_id: str, row: list[tuple[OcrText, VisualState]], kind: str, reason: str) -> list[dict[str, Any]]:
        evidence: list[dict[str, Any]] = []
        for item, state in row:
            evidence.append({"roi_id": roi_id, "bbox": item.bbox(), "type": kind, "ocr_score": item.score, "reason": reason})
            evidence.extend({**entry, "roi_id": roi_id} for entry in state.evidence if entry.get("type") == kind and entry.get("bbox") != item.bbox())
        return evidence

    def _key_for_label(self, text: str) -> str | None:
        low = text.lower()
        for key, words in self.LABELS.items():
            if any(word.lower() in low for word in words):
                return key
        return None

    def _stable_key(self, label: str) -> str:
        return re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_") or "unresolved"

    @staticmethod
    def _number(raw: str) -> int | float:
        value = float(raw.replace(",", "."))
        return int(value) if value.is_integer() else value

    @staticmethod
    def _enabled(row: list[tuple[OcrText, VisualState]]) -> str:
        values = [state.enabled for _, state in row if state.enabled != "unknown"]
        return values[0] if values and all(value == values[0] for value in values) else "unknown"

    @staticmethod
    def _is_heading(text: str) -> bool:
        low = text.lower()
        return any(word.lower() in low for word in PanelParser.NON_NAME) or len(text) <= 1

    def _is_name_candidate(self, text: str) -> bool:
        return not self._is_heading(text) and not any(NUMBER_RE.search(text) for _ in [0]) and len(text) >= 2

    @staticmethod
    def _looks_truncated(text: str, bbox: list[int]) -> bool:
        return text.endswith(("…", "...", "…")) or bbox[2] >= 240
